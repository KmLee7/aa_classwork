class Room
    def initialize (number)
        @capacity = number
        @occupants = []
    end
    def capacity
        @capacity
    end
    def occupants
        @occupants
    end
    def full?
        if @occupants.length < @capacity
            return false
        elsif @occupants.length == @capacity
            return true
        end
    end
    def available_space
        @available_space = @capacity - @occupants.length
    end
    def add_occupant(name)
        if !(self.full?)
            @occupants << name
            return true
        end
        false
    end
end