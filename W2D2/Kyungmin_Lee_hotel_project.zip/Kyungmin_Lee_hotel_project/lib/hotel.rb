require_relative "room"

class Hotel
    def initialize (name, capacities)
        @name = name
        @rooms = {}

        capacities.each do |room_names, capacity|
            @rooms[room_names] = Room.new(capacity)
        end
    end
    def name 
        @name.split(" ").map(&:capitalize).join(" ")
    end
    def rooms
        @rooms
    end
    def room_exists?(string)
        if @rooms.has_key?(string)
            return true
        else
            return false
        end
    end
    def check_in(person_str, room_name_str)
        if self.room_exists?(room_name_str)
           if @rooms[room_name_str].add_occupant(person_str)
                print "check in successful"
            else
                print "sorry, room does not exist"
            end
        else 
            print "sorry, room is full"
        end
    end
    def has_vacancy?
        @rooms.values.any? {|room| room.available_space > 0}
    end
    def list_rooms
        @rooms.each do |room_names, room|
            puts "#{room_names} : #{room.available_space}"
        end
    end
end
